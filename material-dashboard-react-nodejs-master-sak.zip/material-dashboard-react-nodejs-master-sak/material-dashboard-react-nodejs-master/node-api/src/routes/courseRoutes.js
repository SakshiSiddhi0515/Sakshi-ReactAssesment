// src/routes/courseRoutes.js
import express from 'express';

const router = express.Router();

// Get a specific course by ID
router.get('/courses/:id', async (req, res) => {
  try {
    const course = await Course.findById(req.params.id);
    if (!course) return res.status(404).json({ message: 'Course not found' });
    res.json(course);
  } catch (error) {
    res.status(500).json({ message: 'Server error' });
  }
});

// Unlock all modules of a course after purchase
router.post('/courses/:id/unlock', async (req, res) => {
  try {
    const course = await Course.findById(req.params.id);
    if (!course) return res.status(404).json({ message: 'Course not found' });

    // Unlock all modules
    course.modules.forEach(module => module.isLocked = false);
    await course.save();

    res.json(course);
  } catch (error) {
    res.status(500).json({ message: 'Server error' });
  }
});

export default router;
