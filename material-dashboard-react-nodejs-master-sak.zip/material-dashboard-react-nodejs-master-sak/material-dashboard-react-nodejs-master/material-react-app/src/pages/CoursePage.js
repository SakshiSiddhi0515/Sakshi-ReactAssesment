import React, { useState, useEffect } from 'react';

const CoursePage = ({ match }) => {
  const [course, setCourse] = useState(null);
  const [loading, setLoading] = useState(true); // To manage loading state
  const [error, setError] = useState(null); // To manage errors
  const [purchased, setPurchased] = useState(false); // To track if the course is purchased

  // Fetch course data from the backend
  useEffect(() => {
    const fetchCourse = async () => {
      try {
        const response = await fetch(`/api/courses/${match.params.id}`);
        const data = await response.json();
        setCourse(data);
        setLoading(false); // Disable loading state once data is fetched
      } catch (error) {
        console.error('Error fetching course:', error);
        setError('Failed to fetch course details');
        setLoading(false);
      }
    };

    fetchCourse();
  }, [match.params.id]);

  // Function to handle course purchase
  const purchaseCourse = async () => {
    try {
      const response = await fetch(`/api/courses/${match.params.id}/unlock`, {
        method: 'POST',
      });
      const data = await response.json();
      setCourse(data);  // Update course to reflect unlocked modules
      setPurchased(true); // Set the purchased state to true
    } catch (error) {
      console.error('Error purchasing course:', error);
      setError('Failed to unlock the course.');
    }
  };

  if (loading) return <div>Loading...</div>;  // Display a loading message while fetching data
  if (error) return <div>{error}</div>;  // Display error if there's an issue fetching data

  return (
    <div>
      <h1>{course.title}</h1>
      <p>{course.description}</p>

      {/* Purchase button */}
      {!purchased && (
        <button onClick={purchaseCourse} style={{ marginBottom: '20px' }}>
          Purchase Course
        </button>
      )}

      <h2>Modules</h2>
      <ul>
        {course.modules.map((module, index) => (
          <li key={index} style={{ marginBottom: '30px' }}>
            <h3>{module.title}</h3>
            {module.isLocked ? (
              <p>This module is locked. Please purchase the course to unlock it.</p>
            ) : (
              <div>
                {/* Display module content if unlocked */}
                {module.slideUrl && (
                  <div style={{ marginBottom: '20px' }}>
                    <iframe
                      src={module.slideUrl}
                      title={`Slide ${index + 1}`}
                      width="600"
                      height="400"
                    ></iframe>
                  </div>
                )}
                {module.videoUrl && (
                  <div style={{ marginBottom: '20px' }}>
                    <video width="600" controls>
                      <source src={module.videoUrl} type="video/mp4" />
                      Your browser does not support the video tag.
                    </video>
                  </div>
                )}
                {module.text && <p>{module.text}</p>}
              </div>
            )}
          </li>
        ))}
      </ul>
    </div>
  );
};

export default CoursePage;
