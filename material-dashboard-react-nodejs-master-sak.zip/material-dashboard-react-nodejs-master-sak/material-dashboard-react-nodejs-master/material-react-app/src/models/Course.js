// src/models/Course.js
import mongoose from 'mongoose';

const moduleSchema = new mongoose.Schema({
  title: String,
  slideUrl: String,
  videoUrl: String,
  text: String,
  isLocked: {
    type: Boolean,
    default: true,  // Initially locked
  },
});

const courseSchema = new mongoose.Schema({
  title: { type: String, required: true },
  description: String,
  modules: [moduleSchema],  // An array of modules
});

export const Course = mongoose.model('Course', courseSchema);
