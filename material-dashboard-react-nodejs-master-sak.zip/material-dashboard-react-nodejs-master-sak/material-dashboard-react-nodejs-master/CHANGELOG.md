# Change Log

All notable changes to `React Material Dashboard NodeJs`  will be documented in this file.

## Version 1.0.0

- Authentication: login, logout, forget password and reset password
- Profile update
